﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ZipTreeView")]
[assembly: AssemblyDescription("Example showing a zipfile in a WinForms TreeView")]
[assembly: AssemblyConfiguration("")]

[assembly: ComVisible(false)]

[assembly: Guid("c40b5ebc-ea71-420e-8f61-46582173dbb9")]

